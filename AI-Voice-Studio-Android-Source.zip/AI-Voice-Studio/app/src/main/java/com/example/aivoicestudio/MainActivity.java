package com.example.aivoicestudio;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int CREATE_AUDIO = 101;
    private TextToSpeech tts;
    private EditText script;
    private Spinner languages, voices;
    private SeekBar speed, pitch;
    private TextView status, speedLabel, pitchLabel;
    private final ArrayList<Locale> locales = new ArrayList<>();
    private final ArrayList<Voice> availableVoices = new ArrayList<>();
    private File tempAudio;
    private boolean ready = false;
    private boolean waitingToSave = false;
    private final int background = Color.rgb(13,17,30), panel = Color.rgb(27,34,53), purple = Color.rgb(126,91,255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);
        buildUI();
        tts = new TextToSpeech(this, code -> runOnUiThread(() -> {
            ready = code == TextToSpeech.SUCCESS;
            if (!ready) { showStatus("ไม่พบเครื่องมือเสียงพูด โปรดติดตั้ง Speech Services ของเครื่อง"); return; }
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { runOnUiThread(() -> showStatus("กำลังสร้างเสียง…")); }
                @Override public void onDone(String id) { runOnUiThread(() -> {
                    if ("save".equals(id) && waitingToSave) { waitingToSave = false; openSaveDialog(); }
                    else showStatus("เล่นเสียงเสร็จแล้ว");
                }); }
                @Override public void onError(String id) { runOnUiThread(() -> { waitingToSave=false; showStatus("สร้างเสียงไม่สำเร็จ กรุณาลองเสียงหรือภาษาอื่น"); }); }
            });
            loadLanguages();
            showStatus("พร้อมใช้งาน");
        }));
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density); }
    private TextView text(String value, int size, boolean bold) {
        TextView t=new TextView(this); t.setText(value); t.setTextColor(Color.WHITE); t.setTextSize(size);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private void add(LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(top); parent.addView(child,p);
    }
    private void buildUI() {
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(background);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(32),dp(20),dp(32));
        scroll.addView(root); setContentView(scroll);
        TextView title=text("✦  AI Voice Studio",27,true); add(root,title,0);
        TextView subtitle=text("สร้างเสียงพากย์หลายภาษา • Android",14,false); subtitle.setTextColor(0xffB6BDD4); add(root,subtitle,6);
        TextView label=text("ข้อความสำหรับพากย์",17,true); add(root,label,30);
        script=new EditText(this); script.setTextColor(Color.WHITE); script.setHintTextColor(0xff9098B3);
        script.setTextSize(17); script.setGravity(48); script.setMinLines(6); script.setHint("พิมพ์หรือวางบทพากย์ที่นี่…");
        script.setPadding(dp(16),dp(14),dp(16),dp(14)); script.setBackground(shape(panel,16));
        script.setText("สวัสดีค่ะ ยินดีต้อนรับสู่ AI Voice Studio แอปสร้างเสียงพากย์บนมือถือของคุณ"); add(root,script,12);
        add(root,text("ภาษา",16,true),22);
        languages=new Spinner(this); languages.setBackground(shape(panel,12)); add(root,languages,8);
        add(root,text("เสียงพูด (ขึ้นอยู่กับเสียงที่ติดตั้ง)",16,true),20);
        voices=new Spinner(this); voices.setBackground(shape(panel,12)); add(root,voices,8);
        speedLabel=text("ความเร็ว 1.0×",15,false); add(root,speedLabel,22);
        speed=new SeekBar(this); speed.setMax(150); speed.setProgress(50); add(root,speed,4);
        pitchLabel=text("ระดับเสียง 1.0×",15,false); add(root,pitchLabel,14);
        pitch=new SeekBar(this); pitch.setMax(150); pitch.setProgress(50); add(root,pitch,4);
        speed.setOnSeekBarChangeListener(seek(v -> speedLabel.setText(String.format(Locale.US,"ความเร็ว %.1f×",(v+50)/100f))));
        pitch.setOnSeekBarChangeListener(seek(v -> pitchLabel.setText(String.format(Locale.US,"ระดับเสียง %.1f×",(v+50)/100f))));
        Button play=button("▶  ฟังตัวอย่าง",purple); add(root,play,25); play.setOnClickListener(v -> speak(false));
        Button stop=button("■  หยุดเสียง",panel); add(root,stop,10); stop.setOnClickListener(v -> { if(tts!=null) tts.stop(); showStatus("หยุดเสียงแล้ว"); });
        Button save=button("↓  บันทึกไฟล์เสียง",0xff235E79); add(root,save,10); save.setOnClickListener(v -> speak(true));
        status=text("กำลังเตรียมระบบเสียง…",13,false); status.setTextColor(0xffB6BDD4); add(root,status,20);
        TextView note=text("หมายเหตุ: ภาษาที่มีให้เลือกและคุณภาพเสียงขึ้นอยู่กับระบบ Text-to-Speech ของเครื่อง บันทึกไฟล์ผ่านตัวเลือกตำแหน่งจัดเก็บของ Android",12,false);
        note.setTextColor(0xff8791AC); add(root,note,20);
    }
    private interface Progress { void changed(int value); }
    private SeekBar.OnSeekBarChangeListener seek(Progress p) { return new SeekBar.OnSeekBarChangeListener() {
        public void onProgressChanged(SeekBar s,int value,boolean user){p.changed(value);} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
    }; }
    private Button button(String s,int color) { Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(shape(color,14)); return b; }
    private void showStatus(String s) { status.setText(s); }
    private void loadLanguages() {
        Locale[] choices={new Locale("th","TH"),Locale.ENGLISH,Locale.US,Locale.JAPANESE,Locale.KOREAN,Locale.CHINESE,Locale.FRENCH,Locale.GERMAN,new Locale("es","ES"),new Locale("vi","VN"),new Locale("my","MM"),new Locale("hi","IN")};
        String[] labels={"ไทย", "English (UK)","English (US)","日本語", "한국어", "中文", "Français", "Deutsch", "Español", "Tiếng Việt", "မြန်မာ", "हिन्दी"};
        ArrayList<String> names=new ArrayList<>();
        for(int i=0;i<choices.length;i++) if(tts.isLanguageAvailable(choices[i])>=TextToSpeech.LANG_AVAILABLE) {locales.add(choices[i]);names.add(labels[i]);}
        if(locales.isEmpty()){locales.add(Locale.getDefault());names.add(Locale.getDefault().getDisplayName());}
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);
        languages.setAdapter(adapter);
        languages.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> a) {}
            public void onItemSelected(android.widget.AdapterView<?> a,View v,int position,long id) {loadVoices(locales.get(position));}
        });
    }
    private void loadVoices(Locale locale) {
        availableVoices.clear(); ArrayList<String> names=new ArrayList<>();
        Set<Voice> all=tts.getVoices();
        if(all!=null) for(Voice v:all) if(v.getLocale().getLanguage().equals(locale.getLanguage())) availableVoices.add(v);
        Collections.sort(availableVoices,(a,b)->a.getName().compareTo(b.getName()));
        for(Voice v:availableVoices) names.add(v.getName()+(v.isNetworkConnectionRequired()?" (ต้องใช้อินเทอร์เน็ต)":" (ในเครื่อง)"));
        if(names.isEmpty()) names.add("เสียงมาตรฐาน");
        voices.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
    }
    private void speak(boolean save) {
        if(!ready){showStatus("ระบบเสียงยังไม่พร้อม");return;}
        String content=script.getText().toString().trim();
        if(content.isEmpty()){showStatus("กรุณาใส่ข้อความก่อน");return;}
        if(content.length()>3500){showStatus("ต้นแบบรองรับข้อความไม่เกิน 3,500 ตัวอักษรต่อครั้ง");return;}
        Locale locale=locales.get(languages.getSelectedItemPosition());
        if(tts.setLanguage(locale)<TextToSpeech.LANG_AVAILABLE){showStatus("ยังไม่ได้ติดตั้งเสียงสำหรับภาษานี้");return;}
        int selected=voices.getSelectedItemPosition();
        if(selected>=0 && selected<availableVoices.size()) tts.setVoice(availableVoices.get(selected));
        tts.setSpeechRate((speed.getProgress()+50)/100f); tts.setPitch((pitch.getProgress()+50)/100f);
        if(save) {
            try {tempAudio=new File(getCacheDir(),"voice_export.wav"); if(tempAudio.exists())tempAudio.delete();}
            catch(Exception e){showStatus("ไม่สามารถเตรียมไฟล์ได้");return;}
            waitingToSave=true;
            int result=tts.synthesizeToFile(content,new Bundle(),tempAudio,"save");
            if(result!=TextToSpeech.SUCCESS){waitingToSave=false;showStatus("ไม่สามารถเริ่มบันทึกเสียงได้");}
        } else {
            waitingToSave=false;
            int result=tts.speak(content,TextToSpeech.QUEUE_FLUSH,null,"preview");
            if(result!=TextToSpeech.SUCCESS)showStatus("ไม่สามารถเล่นเสียงได้");
        }
    }
    private void openSaveDialog() {
        if(tempAudio==null || !tempAudio.exists() || tempAudio.length()==0){showStatus("ไม่พบไฟล์เสียงที่สร้าง");return;}
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/wav"); intent.putExtra(Intent.EXTRA_TITLE,"AI-Voice-Studio.wav");
        startActivityForResult(intent,CREATE_AUDIO);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==CREATE_AUDIO && result==RESULT_OK && data!=null && data.getData()!=null) {
            Uri destination=data.getData();
            try(InputStream in=new FileInputStream(tempAudio); OutputStream out=getContentResolver().openOutputStream(destination)) {
                if(out==null)throw new IOException("Output stream unavailable");
                byte[] bytes=new byte[8192]; int n; while((n=in.read(bytes))!=-1)out.write(bytes,0,n);
                showStatus("บันทึกไฟล์เสียงเรียบร้อยแล้ว");
            }catch(Exception e){showStatus("บันทึกไม่สำเร็จ: "+e.getMessage());}
        }else if(request==CREATE_AUDIO)showStatus("ยกเลิกการบันทึก");
    }
    @Override protected void onDestroy() {if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
